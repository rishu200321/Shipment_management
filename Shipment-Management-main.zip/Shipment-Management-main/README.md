#Shipment Management System
This project was made in c++ language  aims to enter the weight and thus by applying knapsack it aims to calculate the appropriate amount of weight that a ship can carry according to its capacity. With the help of djikstra algorithm we can calculate the minimum path possible. Which in turn helps us to calculate the path and weight with which we can have the minimum expense and maximum profit.
Concept used is Array,String, searching.

<img width="371" alt="image" src="https://github.com/2002kartik12/Shipment-Management/assets/110666936/2d9916b5-f13d-43d0-b6a9-c143b2a0acc5">

This is a portal

<img width="291" alt="image" src="https://github.com/2002kartik12/Shipment-Management/assets/110666936/348c09cf-0d53-4c1c-9113-24c265b5e98e">

Here admin user id is 1 and password is 1234

<img width="160" alt="image" src="https://github.com/2002kartik12/Shipment-Management/assets/110666936/465f1667-2c1f-4718-b7d3-1aadf63c91e3">

here is the list where we can assign ships

<img width="405" alt="image" src="https://github.com/2002kartik12/Shipment-Management/assets/110666936/8e7d0a8c-c0d9-4526-8a49-8d5c6aac1d30">

After giving weigth of 354 tonnes the algorithm works and assign tge containers.

<img width="290" alt="image" src="https://github.com/2002kartik12/Shipment-Management/assets/110666936/abed68de-a5bc-4535-b5f6-4cbe79dbf0a3">

this is a map source port is 0 and we give destination port 7 so we get total distance and the cost.

<img width="412" alt="image" src="https://github.com/2002kartik12/Shipment-Management/assets/110666936/e42724ca-1286-444e-82e6-4b1bbd3df3d1">   
This is a DIGITAL INVOICE



